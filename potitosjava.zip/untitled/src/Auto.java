public class Auto {
    String color;
    String placas;
    String modelo;
    int Llantas;
    int puertas;
    Motor motor;
    double velocidad(){
        double velocidadkh=0:
        velocidadkh=motor.fuerza()*Llantas;
        return velocidadkh;
    }
}
