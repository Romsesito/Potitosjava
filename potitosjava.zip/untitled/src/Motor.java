public class Motor {
    int cilindraje;
    int nvalvulas;
    String combustible;

    double fuerza (){
        double fuerzanm=0;
        if (combustible.equals("Gasolina"))
        {


        }
        fuerzanm=nvalvulas*cilindraje;
        return fuerzanm;
}
