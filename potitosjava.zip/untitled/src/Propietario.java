public class Propietario {
    int NumCedula;
    String Nombre;
    String Sector;
    int numtelefono;



}
